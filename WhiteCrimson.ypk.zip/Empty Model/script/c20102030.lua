```lua
--White Crimson
--ID: 20102030

function c20102030.initial_effect(c)

    --Synchro Summon
    Synchro.AddProcedure(c,nil,1,1,Synchro.NonTuner(nil),1,99)
    c:EnableReviveLimit()

    --Always treated as "Artmage"
    local e0=Effect.CreateEffect(c)
    e0:SetType(EFFECT_TYPE_SINGLE)
    e0:SetProperty(EFFECT_FLAG_SINGLE_RANGE)
    e0:SetRange(LOCATION_HAND+LOCATION_MZONE+LOCATION_GRAVE+LOCATION_DECK+LOCATION_EXTRA)
    e0:SetCode(EFFECT_ADD_SETCODE)

    --ARTMAGE SETCODE
    e0:SetValue(0x176)

    c:RegisterEffect(e0)

    --Draw if Special Summoned
    local e1=Effect.CreateEffect(c)
    e1:SetDescription(aux.Stringid(20102030,0))
    e1:SetCategory(CATEGORY_DRAW)
    e1:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_O)
    e1:SetProperty(EFFECT_FLAG_DELAY)
    e1:SetCode(EVENT_SPSUMMON_SUCCESS)
    e1:SetCountLimit(1,20102030)
    e1:SetTarget(c20102030.drtg)
    e1:SetOperation(c20102030.drop)
    c:RegisterEffect(e1)

    --Draw if destroyed
    local e2=e1:Clone()
    e2:SetCode(EVENT_DESTROYED)
    c:RegisterEffect(e2)

    --Quick Effect
    local e3=Effect.CreateEffect(c)
    e3:SetDescription(aux.Stringid(20102030,1))
    e3:SetCategory(CATEGORY_SPECIAL_SUMMON)
    e3:SetType(EFFECT_TYPE_QUICK_O)
    e3:SetCode(EVENT_FREE_CHAIN)
    e3:SetRange(LOCATION_MZONE)
    e3:SetHintTiming(0,TIMINGS_CHECK_MONSTER_E)
    e3:SetCountLimit(1,20102031)
    e3:SetCondition(c20102030.spcon)
    e3:SetTarget(c20102030.sptg)
    e3:SetOperation(c20102030.spop)
    c:RegisterEffect(e3)

end

--Draw Target
function c20102030.drtg(e,tp,eg,ep,ev,re,r,rp,chk)

    if chk==0 then
        return Duel.IsPlayerCanDraw(tp,1)
    end

    Duel.SetTargetPlayer(tp)
    Duel.SetTargetParam(1)

    Duel.SetOperationInfo(
        0,
        CATEGORY_DRAW,
        nil,
        0,
        tp,
        1
    )

end

--Draw Operation
function c20102030.drop(e,tp,eg,ep,ev,re,r,rp)

    local p,d=Duel.GetChainInfo(
        0,
        CHAININFO_TARGET_PLAYER,
        CHAININFO_TARGET_PARAM
    )

    Duel.Draw(p,d,REASON_EFFECT)

end

--3 different Types condition
function c20102030.spcon(e,tp,eg,ep,ev,re,r,rp)

    local g=Duel.GetMatchingGroup(
        Card.IsFaceup,
        tp,
        LOCATION_MZONE,
        0,
        nil
    )

    return g:GetClassCount(Card.GetRace)>=3

end

--Power Patron filter
function c20102030.spfilter(c,e,tp)

    return c:IsSetCard(0x176)
        and c:IsCanBeSpecialSummoned(
            e,
            0,
            tp,
            true,
            true
        )

end

--Target
function c20102030.sptg(e,tp,eg,ep,ev,re,r,rp,chk)

    if chk==0 then

        return Duel.IsExistingMatchingCard(
            c20102030.spfilter,
            tp,
            LOCATION_HAND+
            LOCATION_DECK+
            LOCATION_GRAVE+
            LOCATION_EXTRA,
            0,
            1,
            nil,
            e,
            tp
        )

    end

    Duel.SetOperationInfo(
        0,
        CATEGORY_SPECIAL_SUMMON,
        nil,
        1,
        tp,
        LOCATION_HAND+
        LOCATION_DECK+
        LOCATION_GRAVE+
        LOCATION_EXTRA
    )

end

--Operation
function c20102030.spop(e,tp,eg,ep,ev,re,r,rp)

    local c=e:GetHandler()

    if not c:IsRelateToEffect(e) then
        return
    end

    --Return to Extra Deck
    Duel.SendtoDeck(
        c,
        nil,
        SEQ_DECKSHUFFLE,
        REASON_EFFECT
    )

    Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)

    local g=Duel.SelectMatchingCard(
        tp,
        c20102030.spfilter,
        tp,
        LOCATION_HAND+
        LOCATION_DECK+
        LOCATION_GRAVE+
        LOCATION_EXTRA,
        0,
        1,
        1,
        nil,
        e,
        tp
    )

    local tc=g:GetFirst()

    if tc then

        Duel.SpecialSummon(
            tc,
            0,
            tp,
            tp,
            true,
            true,
            POS_FACEUP
        )

        tc:CompleteProcedure()

    end

end
```




